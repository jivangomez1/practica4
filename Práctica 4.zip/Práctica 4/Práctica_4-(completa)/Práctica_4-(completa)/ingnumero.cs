﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class ingnumero
    {
        public ingnumero()
        {
            Console.Write("Ingrese el número " + (Program.indice + 1) + " = ");
            //Validando para que el usuario solo pueda ingresar valores numéricos
            try
            {
                vector.numeros[Program.indice] = Convert.ToDouble(Console.ReadLine());
            }
            catch (Exception)
            {
                //Mostrando un mensajede error si no se cumple la validación
                Console.WriteLine(" ");
                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                Console.WriteLine(" ------------------------------------------------------------ ");
                Console.WriteLine(" ");
                v_erroneo erroneo = new v_erroneo();
            }
        }
    }
}
