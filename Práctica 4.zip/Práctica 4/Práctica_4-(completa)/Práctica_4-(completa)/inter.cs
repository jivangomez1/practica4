﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class inter
    {
        public inter()
        {
            Console.WriteLine(" ");
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");
            try {
                    Console.Write("Ingrese la primera posición = ");
                    Program.pos1 = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Ingrese la segunda posición = ");
                    Program.pos2 = Convert.ToInt32(Console.ReadLine());
                if (Program.pos1 >= 0 && Program.pos2 >= 0 && Program.pos1 < Program.n - 1 && Program.pos2 < Program.n - 1 && Program.pos1 != Program.pos2)
                {
                    Program.temp = vector.numeros[Program.pos1];
                    vector.numeros[Program.pos1] = vector.numeros[Program.pos2];
                    vector.numeros[Program.pos2] = Program.temp;
                    Console.WriteLine(" ");
                    Console.WriteLine("***************************************************************");
                    Console.WriteLine(" ");
                    Console.WriteLine("Su nuevo vector es = ");
                    Console.WriteLine(" ");
                    for (Program.indice = 0; Program.indice < vector.numeros.Length; Program.indice++)
                    {
                        Console.WriteLine("Numero " + (Program.indice + 1) + " = " + vector.numeros[Program.indice]);
                    }
                }
                else
                {
                    Console.WriteLine(" ");
                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                    Console.WriteLine(" |        ¡Una o ambas posiciones están por fuera del       | ");
                    Console.WriteLine(" |             tamaño del vector o son iguales!             | ");
                    Console.WriteLine(" ------------------------------------------------------------ ");
                    Console.WriteLine(" ");
                    inter intercambiar = new inter();
                }
            }
            catch (Exception)
            {
                Console.WriteLine(" ");
                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                Console.WriteLine(" ------------------------------------------------------------ ");
                Console.WriteLine(" ");
                inter intercambiar = new inter();
            }
        }
    }
}
