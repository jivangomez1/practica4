﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class v_erroneo
    {
        public v_erroneo()
        {
            //Solicitando al usuario si desea rellena el campo vacio y validando su respuesta
            try
            {
                Console.Write("¿Desea ingresar este valor? = ");
                Program.sn1 = Convert.ToString(Console.ReadLine());
                Console.WriteLine(" ");
                //Validando la respuesta del usuario para poder continuar
                if (Program.sn1 == "Si" || Program.sn1 == "si" || Program.sn1 == "SI")
                {
                    //Solicitando nuevamente el número
                    Console.WriteLine("***************************************************************");
                    Console.WriteLine(" ");
                    //Clase --> 'ingreso de número'
                    ingnumero ingreso = new ingnumero();
                }
                else
                {
                    //Validando la respuesta del usuario para poder continuar
                    if (Program.sn1 == "No" || Program.sn1 == "no" || Program.sn1 == "NO")
                    {
                        //Indicando al usuario que ese número será igual a 0
                        Console.WriteLine(" * Su número se rellenará automáticamente con valor '0' *");
                        Console.WriteLine(" ");
                        Console.WriteLine("***************************************************************");
                        Console.WriteLine(" ");
                        vector.numeros[Program.indice] = 0;
                    }
                    else
                    {
                        //Validando para que el usuario solo pueda ingresar 'Si' o 'No'
                        Console.WriteLine("***************************************************************");
                        Console.WriteLine(" ");
                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                        Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                        Console.WriteLine(" ------------------------------------------------------------ ");
                        Console.WriteLine(" ");
                        v_erroneo ingreso = new v_erroneo();
                    }

                }
            }
            catch(Exception)
            {

            }
        }
    }
}
