﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class modificar1
    {
        public modificar1()
        {
            //Usando Do While para repetir el ciclo hasta que el usuario no desee modificar los valores del vector
            do
            {
                //Mostrando el vector
                Console.WriteLine(" ");
                Console.WriteLine("***************************************************************");
                Console.WriteLine(" ");
                //Preguntando al usuario sidesea modificar algún valor del vector
                Console.Write("¿Desea modificar algún valor de su vector? = ");
                Program.sn2 = Convert.ToString(Console.ReadLine());
                Console.WriteLine(" ");
                //Convirtiendo la respuesta en mayuscula
                Program.sn2 = Program.sn2.ToUpper();
                //Validando la respuesta del usuario para poder continuar
                if (Program.sn2.Equals("SI"))
                {
                    posicion pos = new posicion();
                }
                Console.WriteLine("Su vector es=");
                Console.WriteLine(" ");
                for (Program.indice = 0; Program.indice < vector.numeros.Length; Program.indice++)
                {
                    Console.WriteLine("Numero " + (Program.indice + 1) + " = " + (vector.numeros[Program.indice]));
                }
            } while (Program.sn2.Equals("SI"));

            if (Program.sn2.Equals("NO"))
            {
                cambpos cambpos = new cambpos();
            }
            else
            {
                Console.WriteLine(" ");
                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                Console.WriteLine(" ------------------------------------------------------------ ");
                Console.WriteLine(" ");
                modificar1 mod1 = new modificar1();
            }
        }
    }
}
