﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class principal
    {
        public principal()
        {
            //Titulo
            Console.WriteLine("***************************************************************");
            Console.WriteLine("                           PRÁCTICA 4                          ");

            //Clase --> 'Cantidad de Números del Vector'
            c_n_v cantidad = new c_n_v();

            //Clase --> 'Vector'
            vector vec = new vector();
        }
    }
}
