﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class mame
    {
        public mame()
        {
            for (Program.indice = 0; Program.indice < vector.numeros.Length; Program.indice++)
            {
                for (Program.j = Program.indice + 1; Program.j < vector.numeros.Length; Program.j++)
                {
                    if (vector.numeros[Program.indice] < vector.numeros[Program.j])
                    {
                        Program.temp = vector.numeros[Program.indice];
                        vector.numeros[Program.indice] = vector.numeros[Program.j];
                        vector.numeros[Program.j] = Program.temp;
                    }
                }
            }
            Console.WriteLine(" ");
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");
            Console.WriteLine("Su vector ordenado de mayor a menor es = ");
            Console.WriteLine(" ");
            for (Program.indice = 0; Program.indice < vector.numeros.Length; Program.indice++)
            {
                Console.WriteLine("Numero " + (Program.indice + 1) + " = " + vector.numeros[Program.indice]);
            }
        }
    }
}
