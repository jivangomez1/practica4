﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class seguir
    {
        public seguir()
        {
            Console.WriteLine(" ");
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");
            Console.Write("¿Desea seguir jugando? = ");
            Program.snf = Convert.ToString(Console.ReadLine());
            if (Program.snf == "Si" || Program.snf == "si" || Program.snf == "SI")
            {
                juego juego = new juego();
            }
            else
            {
                if (Program.snf == "No" || Program.snf == "no" || Program.snf == "NO")
                {
                    reiniciar rein = new reiniciar();
                }
                else
                {
                    Console.WriteLine(" ");
                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                    Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                    Console.WriteLine(" ------------------------------------------------------------ ");
                    seguir seguir = new seguir();
                }
            }
        }
    }
}
