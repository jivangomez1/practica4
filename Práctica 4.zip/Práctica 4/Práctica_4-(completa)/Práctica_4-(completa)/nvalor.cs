﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class nvalor
    {
        public nvalor()
        {
            Console.WriteLine(" ");
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");
            Console.Write("Ingrese el nuevo valor = ");
            try
            {
                Program.nn = Convert.ToDouble(Console.ReadLine());
                vector.numeros[Program.posicion] = Program.nn;
                Console.WriteLine(" ");
            }
            catch (Exception)
            {
                Console.WriteLine(" ");
                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                Console.WriteLine(" ------------------------------------------------------------ ");
                Console.WriteLine(" ");
                nvalor nv = new nvalor();
            }
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");
        }
    }
}
