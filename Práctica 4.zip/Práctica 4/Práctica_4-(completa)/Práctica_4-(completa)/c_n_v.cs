﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class c_n_v
    {
        public c_n_v()
        {
            //Solicitando al usuario la cantidad de números que tendrá el vector
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");
            Console.Write("¿De cuantos números desea que sea su vector? = ");
            //Validando para que el usuario solo pueda ingresar valores numéricos
            try
            {
                Program.n = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception)
            {
                //Mostrando un mensajede error si no se cumple la validación
                Console.WriteLine(" ");
                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                Console.WriteLine(" |   ¡Recuerde que solo puede ingresar valores numéricos!   | ");
                Console.WriteLine(" ------------------------------------------------------------ ");
                Console.WriteLine(" ");

                //Clase --> 'Cantidad de Números del Vector' (post error)
                c_n_v cantidad = new c_n_v();
            }
        }
    }
}
