﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class cambpos
    {
        public cambpos()
        {
            do
            {
                Console.WriteLine(" ");
                Console.WriteLine("***************************************************************");
                Console.WriteLine(" ");
                Console.Write("¿Desea intercambiar valores entre dos posiciones? = ");
                Program.sn4 = Convert.ToString(Console.ReadLine());
                Program.sn4 = Program.sn4.ToUpper();
                if (Program.sn4.Equals("SI"))
                {
                    inter intercambiar = new inter();
                }
            } while (Program.sn4.Equals("SI"));
            if (Program.sn4.Equals("NO"))
            {
                juego juego = new juego();
            }
            else
            {
                Console.WriteLine(" ");
                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                Console.WriteLine(" ------------------------------------------------------------ ");
                Console.WriteLine(" ");
                cambpos cambpos = new cambpos();
            }
        }
    }
}
