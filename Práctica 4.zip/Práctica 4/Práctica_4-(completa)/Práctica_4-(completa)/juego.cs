﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class juego
    {
        public juego()
        {
            Console.WriteLine(" ");
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");
            Console.WriteLine("¡¡Ahora puede jugar con su vector señalando la opción que más desee!!");
            Console.WriteLine(" ");
            Console.WriteLine("(1) --> Invertir orden");
            Console.WriteLine("(2) --> Ordenar de menor a mayor");
            Console.WriteLine("(3) --> Ordenar de mayor a menor");
            Console.WriteLine(" ");
            opcion opcion = new opcion();
            seguir seguir = new seguir();    
        }
    }
}
