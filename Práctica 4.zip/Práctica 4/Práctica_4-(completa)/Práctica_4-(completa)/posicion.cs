﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class posicion
    {
        public posicion()
        {
            //Solcitando al usuario la posición del número que desea cambiar 
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");
            Console.Write("Ingrese la posición del número que desea modificar = ");
            //Validando para que el usuario solo pueda ingresar un número entero
            try
            {
                Program.posicion = Convert.ToInt32(Console.ReadLine());
                //Validando si la posición ingresada está dentro del rango del vector
                if (Program.posicion >= 0 && Program.posicion < vector.numeros.Length)
                {
                    nvalor nv = new nvalor();                
                }
                else
                {
                    Console.WriteLine(" ");
                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                    Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                    Console.WriteLine(" |                  del tamaño del vector!                  | ");
                    Console.WriteLine(" ------------------------------------------------------------ ");
                    Console.WriteLine(" ");
                    posicion pos = new posicion();
                }
            }
            catch (Exception)
            {
                Console.WriteLine(" ");
                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                Console.WriteLine(" ------------------------------------------------------------ ");
                Console.WriteLine(" ");
                posicion pos = new posicion();
            }
        }
    }
}
