﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class inver
    {
        double aux;
        public inver()
        {
            Console.WriteLine(" ");
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");
            Console.WriteLine("Su vector invertido es = ");
            Console.WriteLine(" ");
            for (Program.indice = 0; Program.indice < Program.n; Program.indice++)
            {
                Console.WriteLine("Numero " + (Program.indice + 1) + " = " + vector.numeros[Program.n - Program.indice - 1]);
            }
        }
    }
}
