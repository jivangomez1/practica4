﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class reiniciar
    {
        public reiniciar()
        {
            Console.WriteLine(" ");
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");
            Console.Write("¿Desea reiniciar el programa? = ");
            Program.snr = Convert.ToString(Console.ReadLine());
            Console.WriteLine(" ");
            if (Program.snr == "Si" || Program.snr == "si" || Program.snr == "SI")
            {
                principal prin = new principal();
            }
            else
            {
                if (Program.snr == "No" || Program.snr == "no" || Program.snr == "NO")
                {
                    
                }
                else
                {
                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                    Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                    Console.WriteLine(" ------------------------------------------------------------ ");
                    reiniciar rein = new reiniciar();
                }
            }
        }
    }
}
