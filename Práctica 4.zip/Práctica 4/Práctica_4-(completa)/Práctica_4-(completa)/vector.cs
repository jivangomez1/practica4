﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class vector
    {
        //Declarando al vector
        public static double[] numeros = new double[Program.n];
        public static double[] numerosinv = new double[Program.n];

        //Creando una instancia de Random
        public static Random aleatorio = new Random();

        public vector()
        {
            //Solicitando al usuario si desea ingresar los valores del vecto o no
            Console.WriteLine(" ");
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");
            Console.Write("¿Desea usted dar los valores del vector? = ");
            Program.sn = Convert.ToString(Console.ReadLine());
            Console.WriteLine(" ");
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");

            //Validando la respuesta del usuario para poder continuar
            if (Program.sn == "Si" || Program.sn == "si" || Program.sn == "SI")
            {
                //Solicitando los datos del vector
                for (Program.indice = 0; Program.indice < numeros.Length; Program.indice++)
                {
                    //Usando Do While para repetir el ciclo hasta que el usuario no desee modificar los valores del vector
                    ingnumero ingreso = new ingnumero();
                }
                Console.WriteLine(" ");
                modificar1 mod1 = new modificar1();
            }
            else
            {
                if (Program.sn == "No" || Program.sn == "no" || Program.sn == "NO")
                {
                    Console.WriteLine("Su vector es=");
                    Console.WriteLine(" ");
                    for (Program.indice = 0; Program.indice < vector.numeros.Length; Program.indice++)
                        {
                            vector.numeros[Program.indice] = (vector.aleatorio.Next(0, 100));
                            Console.WriteLine("Numero " + (Program.indice + 1) + " = " + (vector.numeros[Program.indice]));
                        }
                    modificar1 mod = new modificar1();
                }
                else
                {
                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                    Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                    Console.WriteLine(" ------------------------------------------------------------ ");
                    vector vec = new vector();
                }
            }
        }
    }
}
