﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class opcion
    {
        public opcion()
        {
            Console.Write("Indique la opción que desea = ");
            try
            {
                Program.option = Convert.ToInt32(Console.ReadLine());
                if (Program.option > 0 && Program.option < 4)
                {
                    if (Program.option == 1)
                    {
                        inver invertido = new inver();
                    }
                    else
                    {
                        if (Program.option == 2)
                        {
                            mema mema = new mema();
                        }
                        else
                        {
                            if (Program.option == 3)
                            {
                                mame mame = new mame();
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine(" ");
                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                    Console.WriteLine(" |            ¡Este número no pertenece a ninguna           | ");
                    Console.WriteLine(" |                de las anteriores opciones!               | ");
                    Console.WriteLine(" ------------------------------------------------------------ ");
                    Console.WriteLine(" ");
                    opcion opcion = new opcion();
                }
            }
            catch (Exception)
            {
                Console.WriteLine(" ");
                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                Console.WriteLine(" ------------------------------------------------------------ ");
                Console.WriteLine(" ");
                opcion opcion = new opcion();
            }
        }
    }
}
