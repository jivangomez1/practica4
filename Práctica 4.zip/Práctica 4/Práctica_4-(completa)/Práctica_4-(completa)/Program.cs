﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_4__completa_
{
    class Program
    {
        //Declarando variables públicas para todas las clases
        public static int n;
        public static int indice;
        public static int j;
        public static int posicion;
        public static int option;
        public static int pos1;
        public static int pos2;
        public static string sn;
        public static string sn1;
        public static string sn2;
        public static string sn4;
        public static string snf;
        public static string snr;
        public static double nn;
        public static double temp;
        static void Main(string[] args)
        {
            //INICIO

            //Clase --> 'Principal'
            principal prin = new principal();

            //FINAL
        }
    }
}