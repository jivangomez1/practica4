﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica4_Lógica
{
    class Program
    {
        static void Main(string[] args)
        {
            //INCIO

            //Titulo
            Console.WriteLine("***************************************************************");
            Console.WriteLine("                           PRÁCTICA 4                          ");
            Console.WriteLine("***************************************************************");

            //Declarando variable
            int n, indice, posicion;
            string sn, sn1, sn2, sn3;
            double nn;

            //Solicitando al usuario el tamaño del vector
            Console.WriteLine(" ");
            Console.Write("¿De cuantos números desea que sea su vector? = ");
            //Validando para que el usuario solo pueda ingresar valores numéricos
            try
            {
                n = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception)
            {
                Console.WriteLine(" ");
                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                Console.WriteLine(" |   ¡Recuerde que solo puede ingresar valores numéricos!   | ");
                Console.WriteLine(" ------------------------------------------------------------ ");
                Console.WriteLine(" ");
                Console.WriteLine("***************************************************************");
                Console.WriteLine(" ");
                //Solicitando nuevamente al usuario el tamaño del vector después del error
                Console.Write("¿De cuantos números desea que sea su vector? = ");
                n = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine(" ");
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");

            //Solicitando al usuario si desea ingresar los valores del vector o no
            Console.Write("¿Desea usted dar los valores del vector? = ");
            sn = Convert.ToString(Console.ReadLine());
            Console.WriteLine(" ");
            Console.WriteLine("***************************************************************");
            Console.WriteLine(" ");

            //Declarando al vector
            double[] numeros = new double[n];

            //Creando una instancia de Random
            Random aleatorio = new Random();

            //Validando la respuesta del usuario para poder continuar
            if (sn == "Si" || sn == "si" || sn == "SI")
            {
                //Solicitando los datos del vector
                for (indice = 0; indice < numeros.Length; indice++)
                {
                    Console.Write("Ingrese el número " + (indice + 1) + " = ");
                    //Validando para que el usuario solo pueda ingresar valores numéricos
                    try
                    {
                        numeros[indice] = Convert.ToDouble(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                        Console.WriteLine(" ------------------------------------------------------------ ");
                        Console.WriteLine(" ");
                        //Solicitando al usuario si desea rellena el campo vacio y validando su respuesta
                        try
                        {
                            Console.Write("¿Desea ingresar este valor? = ");
                            sn1 = Convert.ToString(Console.ReadLine());
                            Console.WriteLine(" ");
                            //Validando la respuesta del usuario para poder continuar
                            if (sn1 == "Si" || sn1 == "si" || sn1 == "SI")
                            {
                                //Solicitando nuevamente el número
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                Console.Write("Ingrese el número " + (indice + 1) + " = ");
                                numeros[indice] = Convert.ToDouble(Console.ReadLine());
                            }
                            else
                            {
                                //Validando la respuesta del usuario para poder continuar
                                if (sn1 == "No" || sn1 == "no" || sn1 == "NO")
                                {
                                    Console.WriteLine(" * Su número se rellenará automáticamente con valor '0' *");
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    numeros[indice] = 0;
                                }
                                else
                                {
                                    //Validando para que el usuario solo pueda ingresar 'Si' o 'No'
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                    Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                    Console.WriteLine(" ");
                                    //Preguntando al usuario si desea ingresar el número que fue erroneo
                                    Console.Write("¿Desea ingresar este valor? = ");
                                    sn1 = Convert.ToString(Console.ReadLine());
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                }
                            }
                        }
                        catch (Exception)
                        {

                        }
                    }
                }
                Console.WriteLine(" ");
                //Usando Do While para repetir el ciclo hasta que el usuario no desee modificar los valores del vector
                do
                {
                    //Mostrando el vector con todos los números ingresados
                    Console.WriteLine("***************************************************************");
                    Console.WriteLine(" ");
                    Console.WriteLine("Su vector es =");
                    Console.WriteLine(" ");

                    for (indice = 0; indice < numeros.Length; indice++)
                    {
                        Console.WriteLine("Numero " + (indice + 1) + " = " + (numeros[indice]));
                    }
                    Console.WriteLine(" ");
                    //Solicitando al usuario si desea modificar algun valor del vector
                    Console.WriteLine("***************************************************************");
                    Console.WriteLine(" ");
                    Console.Write("¿Desea modificar algún valor de su vector? = ");
                    sn2 = Convert.ToString(Console.ReadLine());
                    Console.WriteLine(" ");
                    //Convierto la respuesta del usuario a mayuscula
                    sn2 = sn2.ToUpper();
                    //Validando la respuesta del usuario para poder continuar
                    if (sn2.Equals("SI"))
                    {
                        //Solcitando al usuario la posición del número que desea cambiar 
                        Console.WriteLine("***************************************************************");
                        Console.WriteLine(" ");
                        Console.Write("Ingrese la posición del número que desea modificar = ");
                        //validando para que el usuario solo pueda ingresar valores numéricos
                        try
                        {
                            posicion = Convert.ToInt32(Console.ReadLine());
                            //Validando si la posición ingresada está dentro del rango del vector
                            if (posicion > 0 && posicion < numeros.Length)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                //Solcititando al usuario el nuevo valor para el vector
                                Console.Write("Ingrese el nuevo valor = ");
                                //Validando para que el usuario solo pueda ingresar valores numéricos
                                try
                                {
                                    nn = Convert.ToDouble(Console.ReadLine());
                                    numeros[posicion] = nn;
                                    Console.WriteLine(" ");
                                }
                                catch (Exception)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    //Solicitando el nuevo valor (POST ERROR)
                                    Console.Write("Ingrese el nuevo valor = ");
                                    //Validando para que el ususario solo pueda ingresar valores numéricos
                                    try
                                    {
                                        nn = Convert.ToDouble(Console.ReadLine());
                                        numeros[posicion] = nn;
                                        Console.WriteLine(" ");
                                    }
                                    catch (Exception)
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        //Solicitando el nuevo valor (POST ERROR)
                                        Console.Write("Ingrese el nuevo valor = ");
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                Console.WriteLine(" ------------------------------------------------------------ ");
                                Console.WriteLine(" ");
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                //Solicitando al usuario la posición del número que desea modificar (POST ERROR)
                                Console.Write("Ingrese la posición del número que desea modificar = ");
                                posicion = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine(" ");
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                //Validando si la posición ingresada está dentro del rango del vector
                                if (posicion > 0 && posicion < numeros.Length)
                                {
                                    //Solicitando al usuario el nuevo valor
                                    Console.Write("Ingrese el nuevo valor = ");
                                    //Validando para que el usuario solo pueda ingresar valores numéricos
                                    try
                                    {
                                        nn = Convert.ToDouble(Console.ReadLine());
                                        numeros[posicion] = nn;
                                        Console.WriteLine(" ");
                                    }
                                    catch (Exception)
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        //Solicitando el nuevo valor (POST ERROR)
                                        Console.Write("Ingrese el nuevo valor = ");
                                        //Validando para que el usuario solo pueda ingresar valores numéricos
                                        try
                                        {
                                            nn = Convert.ToDouble(Console.ReadLine());
                                            numeros[posicion] = nn;
                                            Console.WriteLine(" ");
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            //Solicitando al usuario el nuevo valor (POST ERROR)
                                            Console.Write("Ingrese el nuevo valor = ");
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception)
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                            Console.WriteLine(" ------------------------------------------------------------ ");
                            Console.WriteLine(" ");
                            Console.WriteLine("***************************************************************");
                            Console.WriteLine(" ");
                            //Solicitando al usuario la posición que desea modificar (POST ERROR)
                            Console.Write("Ingrese la posición del número que desea modificar = ");
                            //Validando para que el usuario solo pueda ingresar valores numéricos
                            try
                            {
                                posicion = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine(" ");
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                //Validando si la posición ingresada está dentro del rango del vector
                                if (posicion > 0 && posicion < numeros.Length)
                                {
                                    //Solicitando al usuario el nuevo valor
                                    Console.Write("Ingrese el nuevo valor = ");
                                    //Validando para que el usuario solo pueda ingresar valores numéricos
                                    try
                                    {
                                        nn = Convert.ToDouble(Console.ReadLine());
                                        numeros[posicion] = nn;
                                        Console.WriteLine(" ");
                                    }
                                    catch (Exception)
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        //Solicitando el nuevo valor (POST ERROR)
                                        Console.Write("Ingrese el nuevo valor = ");
                                        //Validando para que el usuario solo pueda ingresar valores numéricos
                                        try
                                        {
                                            nn = Convert.ToDouble(Console.ReadLine());
                                            numeros[posicion] = nn;
                                            Console.WriteLine(" ");
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            //Solicitando el usuario el nuevo valor (POST ERROR)
                                            Console.Write("Ingrese el nuevo valor = ");
                                        }
                                    }
                                }
                                else
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                    Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                    Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    //Solicitando al usuario la posicion del numero que desea modificar (POST ERROR)
                                    Console.Write("Ingrese la posición del número que desea modificar = ");
                                    posicion = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    //Validando si la posición ingresada está dentro del rango del vector
                                    if (posicion > 0 && posicion < numeros.Length)
                                    {
                                        //Solicitando al usuario el nuevo valor 
                                        Console.Write("Ingrese el nuevo valor = ");
                                        //validando para que el usuario solo pueda ingresar valores numéricos 
                                        try
                                        {
                                            nn = Convert.ToDouble(Console.ReadLine());
                                            numeros[posicion] = nn;
                                            Console.WriteLine(" ");
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            //Solicitando al usuario el nuevo valor (POST ERROR)
                                            Console.Write("Ingrese el nuevo valor = ");
                                            //Validando para que usuario solo pueda ingresar valores numéricos
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                //Solicitando al usuario el nuevo valor (POST ERROR)
                                                Console.Write("Ingrese el nuevo valor = ");
                                            }
                                        }
                                    }
                                }
                            }
                            catch (Exception)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                Console.WriteLine(" ------------------------------------------------------------ ");
                                Console.WriteLine(" ");
                                Console.WriteLine("***************************************************************");
                                //Solicitando al usuario la posicion del número que desea modificar (POST ERROR)
                                Console.Write("Ingrese la posición del número que desea modificar = ");
                            }
                        }
                    }
                } while (sn2.Equals("SI"));
                //Validando la respuesta del usuario para continuar
                if (sn2 == "No" || sn2 == "no" || sn2 == "NO")
                {
                        
                        Console.WriteLine("***************************************************************");
                        Console.WriteLine(" ");
                        Console.WriteLine("Los siento, no alcancé a hacer más :( ");
                        Console.WriteLine("intentaré terminarlo y enviarlo para ver si lo pueden tener en cuenta :) ");
                        Console.WriteLine(" ");
                        Console.WriteLine("***************************************************************");
                        sn3 = Console.ReadLine();
                }
                else
                {
                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                    Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                    Console.WriteLine(" ------------------------------------------------------------ ");
                    Console.WriteLine(" ");
                    do
                    {
                        //Mostrando el vector con todos los números ingresados
                        Console.WriteLine("***************************************************************");
                        Console.WriteLine(" ");
                        Console.WriteLine("Su vector es =");
                        Console.WriteLine(" ");

                        for (indice = 0; indice < numeros.Length; indice++)
                        {
                            Console.WriteLine("Numero " + (indice + 1) + " = " + (numeros[indice]));
                        }
                        Console.WriteLine(" ");
                        //Solicitando al usuario si desea modificar algun valor del vector
                        Console.WriteLine("***************************************************************");
                        Console.WriteLine(" ");
                        Console.Write("¿Desea modificar algún valor de su vector? = ");
                        sn2 = Convert.ToString(Console.ReadLine());
                        Console.WriteLine(" ");
                        sn2 = sn2.ToUpper();
                        //Validando la respuesta del usuario para poder continuar
                        if (sn2.Equals("SI"))
                        {
                            //Solcitando al usuario la posición del número que desea cambiar 
                            Console.WriteLine("***************************************************************");
                            Console.WriteLine(" ");
                            Console.Write("Ingrese la posición del número que desea modificar = ");
                            try
                            {
                                posicion = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine(" ");
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                //Validando si la posición ingresada está dentro del rango del vector
                                if (posicion > 0 && posicion < numeros.Length)
                                {
                                    Console.Write("Ingrese el nuevo valor = ");
                                    try
                                    {
                                        nn = Convert.ToDouble(Console.ReadLine());
                                        numeros[posicion] = nn;
                                        Console.WriteLine(" ");
                                    }
                                    catch (Exception)
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        Console.Write("Ingrese el nuevo valor = ");
                                        try
                                        {
                                            nn = Convert.ToDouble(Console.ReadLine());
                                            numeros[posicion] = nn;
                                            Console.WriteLine(" ");
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese el nuevo valor = ");
                                        }
                                    }
                                }
                                else
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                    Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                    Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    Console.Write("Ingrese la posición del número que desea modificar = ");
                                    posicion = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    //Validando si la posición ingresada está dentro del rango del vector
                                    if (posicion > 0 && posicion < numeros.Length)
                                    {
                                        Console.Write("Ingrese el nuevo valor = ");
                                        try
                                        {
                                            nn = Convert.ToDouble(Console.ReadLine());
                                            numeros[posicion] = nn;
                                            Console.WriteLine(" ");
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                            }
                                        }
                                    }
                                }
                            }
                            catch (Exception)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                Console.WriteLine(" ------------------------------------------------------------ ");
                                Console.WriteLine(" ");
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                Console.Write("Ingrese la posición del número que desea modificar = ");
                                try
                                {
                                    posicion = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    //Validando si la posición ingresada está dentro del rango del vector
                                    if (posicion > 0 && posicion < numeros.Length)
                                    {
                                        Console.Write("Ingrese el nuevo valor = ");
                                        try
                                        {
                                            nn = Convert.ToDouble(Console.ReadLine());
                                            numeros[posicion] = nn;
                                            Console.WriteLine(" ");
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                        Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                        Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        Console.Write("Ingrese la posición del número que desea modificar = ");
                                        posicion = Convert.ToInt32(Console.ReadLine());
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        //Validando si la posición ingresada está dentro del rango del vector
                                        if (posicion > 0 && posicion < numeros.Length)
                                        {
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                }
                                            }
                                        }
                                    }
                                }
                                catch (Exception)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    Console.Write("Ingrese la posición del número que desea modificar = ");
                                }
                            }
                        }
                    } while (sn2.Equals("SI"));
                    if (sn2 == "No" || sn2 == "no" || sn2 == "NO")
                    {
                        Console.WriteLine("***************************************************************");
                        Console.WriteLine(" ");
                        Console.WriteLine("Los siento, no alcancé a hacer más :( ");
                        Console.WriteLine("intentaré terminarlo y enviarlo para ver si lo pueden tener en cuenta :) ");
                        Console.WriteLine(" ");
                        Console.WriteLine("***************************************************************");
                        sn3 = Console.ReadLine();
                    }
                }
            }
            else
            {
                if (sn == "No" || sn == "no" || sn == "NO")
                {
                    do
                    {
                        //Solicitando los datos
                        Console.WriteLine("Su vector es=");
                        Console.WriteLine(" ");
                        for (indice = 0; indice < numeros.Length; indice++)
                        {
                            numeros[indice] = (aleatorio.Next(0, 100));
                            Console.WriteLine("Numero " + (indice + 1) + " = " + (numeros[indice]));
                        }
                        Console.WriteLine(" ");
                        //Usando Do While para repetir el ciclo hasta que el usuario no desee modificar los valores del vector
                        //Mostrando el vector con todos los números ingresados
                        //Solicitando al usuario si desea modificar algun valor del vector
                        Console.WriteLine("***************************************************************");
                        Console.WriteLine(" ");
                        Console.Write("¿Desea modificar algún valor de su vector? = ");
                        sn2 = Convert.ToString(Console.ReadLine());
                        Console.WriteLine(" ");
                        sn2 = sn2.ToUpper();
                        //Validando la respuesta del usuario para poder continuar
                        if (sn2.Equals("SI"))
                        {
                            //Solcitando al usuario la posición del número que desea cambiar 
                            Console.WriteLine("***************************************************************");
                            Console.WriteLine(" ");
                            Console.Write("Ingrese la posición del número que desea modificar = ");
                            try
                            {
                                posicion = Convert.ToInt32(Console.ReadLine());
                                //Validando si la posición ingresada está dentro del rango del vector
                                if (posicion > 0 && posicion < numeros.Length)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    Console.Write("Ingrese el nuevo valor = ");
                                    try
                                    {
                                        nn = Convert.ToDouble(Console.ReadLine());
                                        numeros[posicion] = nn;
                                        Console.WriteLine(" ");
                                    }
                                    catch (Exception)
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        Console.Write("Ingrese el nuevo valor = ");
                                        try
                                        {
                                            nn = Convert.ToDouble(Console.ReadLine());
                                            numeros[posicion] = nn;
                                            Console.WriteLine(" ");
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese el nuevo valor = ");
                                        }
                                    }
                                }
                                else
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                    Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                    Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    Console.Write("Ingrese la posición del número que desea modificar = ");
                                    posicion = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    //Validando si la posición ingresada está dentro del rango del vector
                                    if (posicion > 0 && posicion < numeros.Length)
                                    {
                                        Console.Write("Ingrese el nuevo valor = ");
                                        try
                                        {
                                            nn = Convert.ToDouble(Console.ReadLine());
                                            numeros[posicion] = nn;
                                            Console.WriteLine(" ");
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                            }
                                        }
                                    }
                                }
                            }
                            catch (Exception)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                Console.WriteLine(" ------------------------------------------------------------ ");
                                Console.WriteLine(" ");
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                Console.Write("Ingrese la posición del número que desea modificar = ");
                                try
                                {
                                    posicion = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    //Validando si la posición ingresada está dentro del rango del vector
                                    if (posicion > 0 && posicion < numeros.Length)
                                    {
                                        Console.Write("Ingrese el nuevo valor = ");
                                        try
                                        {
                                            nn = Convert.ToDouble(Console.ReadLine());
                                            numeros[posicion] = nn;
                                            Console.WriteLine(" ");
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                        Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                        Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        Console.Write("Ingrese la posición del número que desea modificar = ");
                                        posicion = Convert.ToInt32(Console.ReadLine());
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        //Validando si la posición ingresada está dentro del rango del vector
                                        if (posicion > 0 && posicion < numeros.Length)
                                        {
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                }
                                            }
                                        }
                                    }
                                }
                                catch (Exception)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    Console.Write("Ingrese la posición del número que desea modificar = ");
                                }
                            }
                        }
                    } while (sn2.Equals("SI"));
                    if (sn2 == "No" || sn2 == "no" || sn2 == "NO")
                    {
                        Console.WriteLine("***************************************************************");
                        Console.WriteLine(" ");
                        Console.WriteLine("Los siento, no alcancé a hacer más :( ");
                        Console.WriteLine("intentaré terminarlo y enviarlo para ver si lo pueden tener en cuenta :) ");
                        Console.WriteLine(" ");
                        Console.WriteLine("***************************************************************");
                        sn3 = Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                        Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                        Console.WriteLine(" ------------------------------------------------------------ ");
                        Console.WriteLine(" ");
                        do
                        {
                            //Mostrando el vector con todos los números ingresados
                            Console.WriteLine("***************************************************************");
                            Console.WriteLine(" ");
                            Console.WriteLine("Su vector es =");
                            Console.WriteLine(" ");

                            for (indice = 0; indice < numeros.Length; indice++)
                            {
                                Console.WriteLine("Numero " + (indice + 1) + " = " + (numeros[indice]));
                            }
                            Console.WriteLine(" ");
                            //Solicitando al usuario si desea modificar algun valor del vector
                            Console.WriteLine("***************************************************************");
                            Console.WriteLine(" ");
                            Console.Write("¿Desea modificar algún valor de su vector? = ");
                            sn2 = Convert.ToString(Console.ReadLine());
                            Console.WriteLine(" ");
                            sn2 = sn2.ToUpper();
                            //Validando la respuesta del usuario para poder continuar
                            if (sn2.Equals("SI"))
                            {
                                //Solcitando al usuario la posición del número que desea cambiar 
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                Console.Write("Ingrese la posición del número que desea modificar = ");
                                try
                                {
                                    posicion = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    //Validando si la posición ingresada está dentro del rango del vector
                                    if (posicion > 0 && posicion < numeros.Length)
                                    {
                                        Console.Write("Ingrese el nuevo valor = ");
                                        try
                                        {
                                            nn = Convert.ToDouble(Console.ReadLine());
                                            numeros[posicion] = nn;
                                            Console.WriteLine(" ");
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                        Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                        Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        Console.Write("Ingrese la posición del número que desea modificar = ");
                                        posicion = Convert.ToInt32(Console.ReadLine());
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        //Validando si la posición ingresada está dentro del rango del vector
                                        if (posicion > 0 && posicion < numeros.Length)
                                        {
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                }
                                            }
                                        }
                                    }
                                }
                                catch (Exception)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    Console.Write("Ingrese la posición del número que desea modificar = ");
                                    try
                                    {
                                        posicion = Convert.ToInt32(Console.ReadLine());
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        //Validando si la posición ingresada está dentro del rango del vector
                                        if (posicion > 0 && posicion < numeros.Length)
                                        {
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                }
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                            Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese la posición del número que desea modificar = ");
                                            posicion = Convert.ToInt32(Console.ReadLine());
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            //Validando si la posición ingresada está dentro del rango del vector
                                            if (posicion > 0 && posicion < numeros.Length)
                                            {
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                    try
                                                    {
                                                        nn = Convert.ToDouble(Console.ReadLine());
                                                        numeros[posicion] = nn;
                                                        Console.WriteLine(" ");
                                                    }
                                                    catch (Exception)
                                                    {
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine("***************************************************************");
                                                        Console.WriteLine(" ");
                                                        Console.Write("Ingrese el nuevo valor = ");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    catch (Exception)
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        Console.Write("Ingrese la posición del número que desea modificar = ");
                                    }
                                }
                            }
                        } while (sn2.Equals("SI"));
                        if (sn2 == "No" || sn2 == "no" || sn2 == "NO")
                        {
                            Console.WriteLine("***************************************************************");
                            Console.WriteLine(" ");
                            Console.WriteLine("Los siento, no alcancé a hacer más :( ");
                            Console.WriteLine("intentaré terminarlo y enviarlo para ver si lo pueden tener en cuenta :) ");
                            Console.WriteLine(" ");
                            Console.WriteLine("***************************************************************");
                            sn3 = Console.ReadLine();
                        }
                    }
                }
                else
                {
                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                    Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                    Console.WriteLine(" ------------------------------------------------------------ ");
                    Console.WriteLine(" ");
                    Console.WriteLine("***************************************************************");
                    Console.WriteLine(" ");
                    Console.Write("¿Desea usted dar los valores del vector? = ");
                    sn = Convert.ToString(Console.ReadLine());
                    Console.WriteLine(" ");
                    Console.WriteLine("***************************************************************");
                    Console.WriteLine(" ");
                    if (sn == "Si" || sn == "si" || sn == "SI")
                    {
                        //Solicitando los datos
                        for (indice = 0; indice < numeros.Length; indice++)
                        {
                            Console.Write("Ingrese el número " + (indice + 1) + " = ");
                            //Validando para que el usuario solo pueda ingresar valores numéricos
                            try
                            {
                                numeros[indice] = Convert.ToDouble(Console.ReadLine());
                            }
                            catch (Exception)
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                Console.WriteLine(" ------------------------------------------------------------ ");
                                Console.WriteLine(" ");
                                //Solicitando al usuario si desea rellena el campo vacio y validando su respuesta
                                try
                                {
                                    Console.Write("¿Desea ingresar este valor? = ");
                                    sn1 = Convert.ToString(Console.ReadLine());
                                    Console.WriteLine(" ");
                                    //Validando la respuesta del usuario para poder continuar
                                    if (sn1 == "Si" || sn1 == "si" || sn1 == "SI")
                                    {
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        Console.Write("Ingrese el número " + (indice + 1) + " = ");
                                        numeros[indice] = Convert.ToDouble(Console.ReadLine());
                                    }
                                    else
                                    {
                                        //Validando la respuesta del usuario para poder continuar
                                        if (sn1 == "No" || sn1 == "no" || sn1 == "NO")
                                        {
                                            Console.WriteLine(" * Su número se rellenará automáticamente con valor '0' *");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            numeros[indice] = 0;
                                        }
                                        else
                                        {
                                            //Validando para que el usuario solo pueda ingresar 'Si' o 'No'
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.Write("¿Desea ingresar este valor? = ");
                                            sn1 = Convert.ToString(Console.ReadLine());
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                        }
                                    }
                                }
                                catch (Exception)
                                {

                                }
                            }
                        }
                        Console.WriteLine(" ");
                        //Usando Do While para repetir el ciclo hasta que el usuario no desee modificar los valores del vector
                        do
                        {
                            //Mostrando el vector con todos los números ingresados
                            Console.WriteLine("***************************************************************");
                            Console.WriteLine(" ");
                            Console.WriteLine("Su vector es =");
                            Console.WriteLine(" ");

                            for (indice = 0; indice < numeros.Length; indice++)
                            {
                                Console.WriteLine("Numero " + (indice + 1) + " = " + (numeros[indice]));
                            }
                            Console.WriteLine(" ");
                            //Solicitando al usuario si desea modificar algun valor del vector
                            Console.WriteLine("***************************************************************");
                            Console.WriteLine(" ");
                            Console.Write("¿Desea modificar algún valor de su vector? = ");
                            sn2 = Convert.ToString(Console.ReadLine());
                            Console.WriteLine(" ");
                            sn2 = sn2.ToUpper();
                            //Validando la respuesta del usuario para poder continuar
                            if (sn2.Equals("SI"))
                            {
                                //Solcitando al usuario la posición del número que desea cambiar 
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                Console.Write("Ingrese la posición del número que desea modificar = ");
                                try
                                {
                                    posicion = Convert.ToInt32(Console.ReadLine());
                                    //Validando si la posición ingresada está dentro del rango del vector
                                    if (posicion > 0 && posicion < numeros.Length)
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        Console.Write("Ingrese el nuevo valor = ");
                                        try
                                        {
                                            nn = Convert.ToDouble(Console.ReadLine());
                                            numeros[posicion] = nn;
                                            Console.WriteLine(" ");
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                        Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                        Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        Console.Write("Ingrese la posición del número que desea modificar = ");
                                        posicion = Convert.ToInt32(Console.ReadLine());
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        //Validando si la posición ingresada está dentro del rango del vector
                                        if (posicion > 0 && posicion < numeros.Length)
                                        {
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                }
                                            }
                                        }
                                    }
                                }
                                catch (Exception)
                                {
                                    Console.WriteLine(" ");
                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    Console.Write("Ingrese la posición del número que desea modificar = ");
                                    try
                                    {
                                        posicion = Convert.ToInt32(Console.ReadLine());
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        //Validando si la posición ingresada está dentro del rango del vector
                                        if (posicion > 0 && posicion < numeros.Length)
                                        {
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                }
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                            Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese la posición del número que desea modificar = ");
                                            posicion = Convert.ToInt32(Console.ReadLine());
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            //Validando si la posición ingresada está dentro del rango del vector
                                            if (posicion > 0 && posicion < numeros.Length)
                                            {
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                    try
                                                    {
                                                        nn = Convert.ToDouble(Console.ReadLine());
                                                        numeros[posicion] = nn;
                                                        Console.WriteLine(" ");
                                                    }
                                                    catch (Exception)
                                                    {
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine("***************************************************************");
                                                        Console.WriteLine(" ");
                                                        Console.Write("Ingrese el nuevo valor = ");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    catch (Exception)
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        Console.Write("Ingrese la posición del número que desea modificar = ");
                                    }
                                }
                            }
                        } while (sn2.Equals("SI"));
                        if (sn2 == "No" || sn2 == "no" || sn2 == "NO")
                        {
                            Console.WriteLine("***************************************************************");
                            Console.WriteLine(" ");
                            Console.WriteLine("Los siento, no alcancé a hacer más :( ");
                            Console.WriteLine("intentaré terminarlo y enviarlo para ver si lo pueden tener en cuenta :) ");
                            Console.WriteLine(" ");
                            Console.WriteLine("***************************************************************");
                            sn3 = Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                            Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                            Console.WriteLine(" ------------------------------------------------------------ ");
                            Console.WriteLine(" ");
                            do
                            {
                                //Mostrando el vector con todos los números ingresados
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                Console.WriteLine("Su vector es =");
                                Console.WriteLine(" ");

                                for (indice = 0; indice < numeros.Length; indice++)
                                {
                                    Console.WriteLine("Numero " + (indice + 1) + " = " + (numeros[indice]));
                                }
                                Console.WriteLine(" ");
                                //Solicitando al usuario si desea modificar algun valor del vector
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                Console.Write("¿Desea modificar algún valor de su vector? = ");
                                sn2 = Convert.ToString(Console.ReadLine());
                                Console.WriteLine(" ");
                                sn2 = sn2.ToUpper();
                                //Validando la respuesta del usuario para poder continuar
                                if (sn2.Equals("SI"))
                                {
                                    //Solcitando al usuario la posición del número que desea cambiar 
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    Console.Write("Ingrese la posición del número que desea modificar = ");
                                    try
                                    {
                                        posicion = Convert.ToInt32(Console.ReadLine());
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        //Validando si la posición ingresada está dentro del rango del vector
                                        if (posicion > 0 && posicion < numeros.Length)
                                        {
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                }
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                            Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese la posición del número que desea modificar = ");
                                            posicion = Convert.ToInt32(Console.ReadLine());
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            //Validando si la posición ingresada está dentro del rango del vector
                                            if (posicion > 0 && posicion < numeros.Length)
                                            {
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                    try
                                                    {
                                                        nn = Convert.ToDouble(Console.ReadLine());
                                                        numeros[posicion] = nn;
                                                        Console.WriteLine(" ");
                                                    }
                                                    catch (Exception)
                                                    {
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine("***************************************************************");
                                                        Console.WriteLine(" ");
                                                        Console.Write("Ingrese el nuevo valor = ");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    catch (Exception)
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        Console.Write("Ingrese la posición del número que desea modificar = ");
                                        try
                                        {
                                            posicion = Convert.ToInt32(Console.ReadLine());
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            //Validando si la posición ingresada está dentro del rango del vector
                                            if (posicion > 0 && posicion < numeros.Length)
                                            {
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                    try
                                                    {
                                                        nn = Convert.ToDouble(Console.ReadLine());
                                                        numeros[posicion] = nn;
                                                        Console.WriteLine(" ");
                                                    }
                                                    catch (Exception)
                                                    {
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine("***************************************************************");
                                                        Console.WriteLine(" ");
                                                        Console.Write("Ingrese el nuevo valor = ");
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                                Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese la posición del número que desea modificar = ");
                                                posicion = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                //Validando si la posición ingresada está dentro del rango del vector
                                                if (posicion > 0 && posicion < numeros.Length)
                                                {
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                    try
                                                    {
                                                        nn = Convert.ToDouble(Console.ReadLine());
                                                        numeros[posicion] = nn;
                                                        Console.WriteLine(" ");
                                                    }
                                                    catch (Exception)
                                                    {
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine("***************************************************************");
                                                        Console.WriteLine(" ");
                                                        Console.Write("Ingrese el nuevo valor = ");
                                                        try
                                                        {
                                                            nn = Convert.ToDouble(Console.ReadLine());
                                                            numeros[posicion] = nn;
                                                            Console.WriteLine(" ");
                                                        }
                                                        catch (Exception)
                                                        {
                                                            Console.WriteLine(" ");
                                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                                            Console.WriteLine(" ");
                                                            Console.WriteLine("***************************************************************");
                                                            Console.WriteLine(" ");
                                                            Console.Write("Ingrese el nuevo valor = ");
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese la posición del número que desea modificar = ");
                                        }
                                    }
                                }
                            } while (sn2.Equals("SI"));
                            if (sn2 == "No" || sn2 == "no" || sn2 == "NO")
                            {
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                Console.WriteLine("Los siento, no alcancé a hacer más :( ");
                                Console.WriteLine("intentaré terminarlo y enviarlo para ver si lo pueden tener en cuenta :) ");
                                Console.WriteLine(" ");
                                Console.WriteLine("***************************************************************");
                                sn3 = Console.ReadLine();
                            }
                        }
                    }
                    else
                    {
                        if (sn == "No" || sn == "no" || sn == "NO")
                        {
                            do
                            {
                                //Solicitando los datos
                                Console.WriteLine("Su vector es=");
                                Console.WriteLine(" ");
                                for (indice = 0; indice < numeros.Length; indice++)
                                {
                                    numeros[indice] = (aleatorio.Next(0, 100));
                                    Console.WriteLine("Numero " + (indice + 1) + " = " + (numeros[indice]));
                                }
                                Console.WriteLine(" ");
                                //Usando Do While para repetir el ciclo hasta que el usuario no desee modificar los valores del vector
                                //Mostrando el vector con todos los números ingresados
                                //Solicitando al usuario si desea modificar algun valor del vector
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                Console.Write("¿Desea modificar algún valor de su vector? = ");
                                sn2 = Convert.ToString(Console.ReadLine());
                                Console.WriteLine(" ");
                                sn2 = sn2.ToUpper();
                                //Validando la respuesta del usuario para poder continuar
                                if (sn2.Equals("SI"))
                                {
                                    //Solcitando al usuario la posición del número que desea cambiar 
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    Console.Write("Ingrese la posición del número que desea modificar = ");
                                    try
                                    {
                                        posicion = Convert.ToInt32(Console.ReadLine());
                                        //Validando si la posición ingresada está dentro del rango del vector
                                        if (posicion > 0 && posicion < numeros.Length)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese el nuevo valor = ");
                                            try
                                            {
                                                nn = Convert.ToDouble(Console.ReadLine());
                                                numeros[posicion] = nn;
                                                Console.WriteLine(" ");
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                }
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                            Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese la posición del número que desea modificar = ");
                                            posicion = Convert.ToInt32(Console.ReadLine());
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            //Validando si la posición ingresada está dentro del rango del vector
                                            if (posicion > 0 && posicion < numeros.Length)
                                            {
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                    try
                                                    {
                                                        nn = Convert.ToDouble(Console.ReadLine());
                                                        numeros[posicion] = nn;
                                                        Console.WriteLine(" ");
                                                    }
                                                    catch (Exception)
                                                    {
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine("***************************************************************");
                                                        Console.WriteLine(" ");
                                                        Console.Write("Ingrese el nuevo valor = ");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    catch (Exception)
                                    {
                                        Console.WriteLine(" ");
                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                        Console.WriteLine(" ");
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        Console.Write("Ingrese la posición del número que desea modificar = ");
                                        try
                                        {
                                            posicion = Convert.ToInt32(Console.ReadLine());
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            //Validando si la posición ingresada está dentro del rango del vector
                                            if (posicion > 0 && posicion < numeros.Length)
                                            {
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                    try
                                                    {
                                                        nn = Convert.ToDouble(Console.ReadLine());
                                                        numeros[posicion] = nn;
                                                        Console.WriteLine(" ");
                                                    }
                                                    catch (Exception)
                                                    {
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine("***************************************************************");
                                                        Console.WriteLine(" ");
                                                        Console.Write("Ingrese el nuevo valor = ");
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                                Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese la posición del número que desea modificar = ");
                                                posicion = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                //Validando si la posición ingresada está dentro del rango del vector
                                                if (posicion > 0 && posicion < numeros.Length)
                                                {
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                    try
                                                    {
                                                        nn = Convert.ToDouble(Console.ReadLine());
                                                        numeros[posicion] = nn;
                                                        Console.WriteLine(" ");
                                                    }
                                                    catch (Exception)
                                                    {
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine("***************************************************************");
                                                        Console.WriteLine(" ");
                                                        Console.Write("Ingrese el nuevo valor = ");
                                                        try
                                                        {
                                                            nn = Convert.ToDouble(Console.ReadLine());
                                                            numeros[posicion] = nn;
                                                            Console.WriteLine(" ");
                                                        }
                                                        catch (Exception)
                                                        {
                                                            Console.WriteLine(" ");
                                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                                            Console.WriteLine(" ");
                                                            Console.WriteLine("***************************************************************");
                                                            Console.WriteLine(" ");
                                                            Console.Write("Ingrese el nuevo valor = ");
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese la posición del número que desea modificar = ");
                                        }
                                    }
                                }
                            } while (sn2.Equals("SI"));
                            if (sn2 == "No" || sn2 == "no" || sn2 == "NO")
                            {
                                Console.WriteLine("***************************************************************");
                                Console.WriteLine(" ");
                                Console.WriteLine("Los siento, no alcancé a hacer más :( ");
                                Console.WriteLine("intentaré terminarlo y enviarlo para ver si lo pueden tener en cuenta :) ");
                                Console.WriteLine(" ");
                                Console.WriteLine("***************************************************************");
                                sn3 = Console.ReadLine();
                            }
                            else
                            {
                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                                Console.WriteLine(" ------------------------------------------------------------ ");
                                Console.WriteLine(" ");
                                do
                                {
                                    //Mostrando el vector con todos los números ingresados
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    Console.WriteLine("Su vector es =");
                                    Console.WriteLine(" ");

                                    for (indice = 0; indice < numeros.Length; indice++)
                                    {
                                        Console.WriteLine("Numero " + (indice + 1) + " = " + (numeros[indice]));
                                    }
                                    Console.WriteLine(" ");
                                    //Solicitando al usuario si desea modificar algun valor del vector
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    Console.Write("¿Desea modificar algún valor de su vector? = ");
                                    sn2 = Convert.ToString(Console.ReadLine());
                                    Console.WriteLine(" ");
                                    sn2 = sn2.ToUpper();
                                    //Validando la respuesta del usuario para poder continuar
                                    if (sn2.Equals("SI"))
                                    {
                                        //Solcitando al usuario la posición del número que desea cambiar 
                                        Console.WriteLine("***************************************************************");
                                        Console.WriteLine(" ");
                                        Console.Write("Ingrese la posición del número que desea modificar = ");
                                        try
                                        {
                                            posicion = Convert.ToInt32(Console.ReadLine());
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            //Validando si la posición ingresada está dentro del rango del vector
                                            if (posicion > 0 && posicion < numeros.Length)
                                            {
                                                Console.Write("Ingrese el nuevo valor = ");
                                                try
                                                {
                                                    nn = Convert.ToDouble(Console.ReadLine());
                                                    numeros[posicion] = nn;
                                                    Console.WriteLine(" ");
                                                }
                                                catch (Exception)
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                    Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                    try
                                                    {
                                                        nn = Convert.ToDouble(Console.ReadLine());
                                                        numeros[posicion] = nn;
                                                        Console.WriteLine(" ");
                                                    }
                                                    catch (Exception)
                                                    {
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine("***************************************************************");
                                                        Console.WriteLine(" ");
                                                        Console.Write("Ingrese el nuevo valor = ");
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                                Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese la posición del número que desea modificar = ");
                                                posicion = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                //Validando si la posición ingresada está dentro del rango del vector
                                                if (posicion > 0 && posicion < numeros.Length)
                                                {
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                    try
                                                    {
                                                        nn = Convert.ToDouble(Console.ReadLine());
                                                        numeros[posicion] = nn;
                                                        Console.WriteLine(" ");
                                                    }
                                                    catch (Exception)
                                                    {
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine("***************************************************************");
                                                        Console.WriteLine(" ");
                                                        Console.Write("Ingrese el nuevo valor = ");
                                                        try
                                                        {
                                                            nn = Convert.ToDouble(Console.ReadLine());
                                                            numeros[posicion] = nn;
                                                            Console.WriteLine(" ");
                                                        }
                                                        catch (Exception)
                                                        {
                                                            Console.WriteLine(" ");
                                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                                            Console.WriteLine(" ");
                                                            Console.WriteLine("***************************************************************");
                                                            Console.WriteLine(" ");
                                                            Console.Write("Ingrese el nuevo valor = ");
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        catch (Exception)
                                        {
                                            Console.WriteLine(" ");
                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                            Console.WriteLine(" ");
                                            Console.WriteLine("***************************************************************");
                                            Console.WriteLine(" ");
                                            Console.Write("Ingrese la posición del número que desea modificar = ");
                                            try
                                            {
                                                posicion = Convert.ToInt32(Console.ReadLine());
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                //Validando si la posición ingresada está dentro del rango del vector
                                                if (posicion > 0 && posicion < numeros.Length)
                                                {
                                                    Console.Write("Ingrese el nuevo valor = ");
                                                    try
                                                    {
                                                        nn = Convert.ToDouble(Console.ReadLine());
                                                        numeros[posicion] = nn;
                                                        Console.WriteLine(" ");
                                                    }
                                                    catch (Exception)
                                                    {
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                        Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                        Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                        Console.WriteLine(" ------------------------------------------------------------ ");
                                                        Console.WriteLine(" ");
                                                        Console.WriteLine("***************************************************************");
                                                        Console.WriteLine(" ");
                                                        Console.Write("Ingrese el nuevo valor = ");
                                                        try
                                                        {
                                                            nn = Convert.ToDouble(Console.ReadLine());
                                                            numeros[posicion] = nn;
                                                            Console.WriteLine(" ");
                                                        }
                                                        catch (Exception)
                                                        {
                                                            Console.WriteLine(" ");
                                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                                            Console.WriteLine(" ");
                                                            Console.WriteLine("***************************************************************");
                                                            Console.WriteLine(" ");
                                                            Console.Write("Ingrese el nuevo valor = ");
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                    Console.WriteLine(" |         ¡la posición que ingresó está por fuera          | ");
                                                    Console.WriteLine(" |                  del tamaño del vector!                  | ");
                                                    Console.WriteLine(" ------------------------------------------------------------ ");
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    Console.Write("Ingrese la posición del número que desea modificar = ");
                                                    posicion = Convert.ToInt32(Console.ReadLine());
                                                    Console.WriteLine(" ");
                                                    Console.WriteLine("***************************************************************");
                                                    Console.WriteLine(" ");
                                                    //Validando si la posición ingresada está dentro del rango del vector
                                                    if (posicion > 0 && posicion < numeros.Length)
                                                    {
                                                        Console.Write("Ingrese el nuevo valor = ");
                                                        try
                                                        {
                                                            nn = Convert.ToDouble(Console.ReadLine());
                                                            numeros[posicion] = nn;
                                                            Console.WriteLine(" ");
                                                        }
                                                        catch (Exception)
                                                        {
                                                            Console.WriteLine(" ");
                                                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                            Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                            Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                            Console.WriteLine(" ------------------------------------------------------------ ");
                                                            Console.WriteLine(" ");
                                                            Console.WriteLine("***************************************************************");
                                                            Console.WriteLine(" ");
                                                            Console.Write("Ingrese el nuevo valor = ");
                                                            try
                                                            {
                                                                nn = Convert.ToDouble(Console.ReadLine());
                                                                numeros[posicion] = nn;
                                                                Console.WriteLine(" ");
                                                            }
                                                            catch (Exception)
                                                            {
                                                                Console.WriteLine(" ");
                                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                                Console.WriteLine(" ");
                                                                Console.WriteLine("***************************************************************");
                                                                Console.WriteLine(" ");
                                                                Console.Write("Ingrese el nuevo valor = ");
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            catch (Exception)
                                            {
                                                Console.WriteLine(" ");
                                                Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                                                Console.WriteLine(" |         ¡Usted ha ingresado un número no válido          | ");
                                                Console.WriteLine(" |             o no ha ingresado ningún valor!              | ");
                                                Console.WriteLine(" ------------------------------------------------------------ ");
                                                Console.WriteLine(" ");
                                                Console.WriteLine("***************************************************************");
                                                Console.WriteLine(" ");
                                                Console.Write("Ingrese la posición del número que desea modificar = ");
                                            }
                                        }
                                    }
                                } while (sn2.Equals("SI"));
                                if (sn2 == "No" || sn2 == "no" || sn2 == "NO")
                                {
                                    Console.WriteLine("***************************************************************");
                                    Console.WriteLine(" ");
                                    Console.WriteLine("Los siento, no alcancé a hacer más :( ");
                                    Console.WriteLine("intentaré terminarlo y enviarlo para ver si lo pueden tener en cuenta :) ");
                                    Console.WriteLine(" ");
                                    Console.WriteLine("***************************************************************");
                                    sn3 = Console.ReadLine();
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine(" --------------------------- ERROR -------------------------- ");
                            Console.WriteLine(" |      ¡Recuerde que solo puede ingresar 'Si' o 'No'!      | ");
                            Console.WriteLine(" ------------------------------------------------------------ ");
                            Console.WriteLine(" ");
                        }
                    }
                }
            }
        }
    }
}